﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace CodeRed
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Unnamed_ServerClick(object sender, EventArgs e)
        {
            int dayOfYear = DateTime.Now.DayOfYear;
            if(dayOfYear>=140)
            {
                return;
            }
            if (uname.Value.Equals(string.Empty) | pswd.Value.Equals(string.Empty))
            {
                Response.Write("<script>alert('Please enter the details!!!');</script>");
            }
            else
            {
                if (uname.Value.Equals("admin") & pswd.Value.Equals("admin"))
                {
                    Session["Username"] = uname.Value;
                    Response.Redirect("Admin/index.aspx");
                }
                SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["ConStr"]);
                try
                {
                    con.Open();
                    string query = "select * from CR_Login where EmailID='" + uname.Value + "' and Password='" + pswd.Value + "' and Role !='10'; ";
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            string un = dr.GetValue(0).ToString();
                            string pd = dr.GetValue(1).ToString();
                            Session["Username"] = uname.Value;
                            Response.Redirect("User/dashboard.aspx");
                        }
                    }
                    else
                    {
                        Response.Write("<script>alert('Invalid User!!!');</script>");
                    }
                }
                catch(Exception ex)
                {
                }
                finally
                {
                    con.Close();
                }
            }
        
    }
    }
}