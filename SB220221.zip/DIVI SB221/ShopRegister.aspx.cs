﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CodeRed
{
	public partial class ShopRegister : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}


        protected void sub_serverclick(object sender, EventArgs e)
        {



            SqlConnection con = new SqlConnection(ConfigurationManager.AppSettings["Constr"]);
            try
            {
                con.Open();
                Random r = new Random();
                String str = "Usr" + r.Next(123, 9999);
                string IPAddress = HttpContext.Current.Request.UserHostAddress;
                string SQL = "";


                SQL = "insert into CR_Login";
                SQL += "           ([FirstName]";
                SQL += "           ,[EmailID]";
                SQL += "           ,[Password]";
                SQL += "           ,[Mobile]";
                SQL += "           ,[Role]";
                SQL += "           ,[aadhaar]";
                SQL += "           ,[addresses])";
                //SQL += "           ,[gender])";
                SQL += " values";
                SQL += "           ('" + (uname.Value) + "'";
                SQL += "           ,'" + (email.Value) + "'";
                SQL += "           ,'" + (pswd.Value) + "'";
                SQL += "           ,'" + (phone.Value) + "' ";
                SQL += "           ,'" + (utype.Value) + "' ";
                SQL += "           ,'" + (aadhar.Value) + "' ";
                SQL += "           ,'" + (ads.Value) + "'";
                //SQL += "           ,'" + (gender.Value) + "' ";            
                SQL += ")";
                SqlCommand cmd = new SqlCommand(SQL, con);
                cmd.ExecuteNonQuery();
                try
                {
                    MailMessage m = new MailMessage("foodnet2020@gmail.com", email.Value, "Welcome Mail !!!", "​Welcome to the Food Network Application !!!\n Your User  name : " + uname.Value + "\n Your Password is: " + pswd.Value + "");
                    SmtpClient s = new SmtpClient("smtp.gmail.com", 587);
                    s.Credentials = new System.Net.NetworkCredential("foodnet2020@gmail.com", "admin@foodnet");
                    s.EnableSsl = true;
                    s.Send(m);
                    Console.WriteLine("Mail Sent");
                }
                catch
                {
                }
                Response.Write("<script>alert('Thank you for registering with us!!!');</script>");
                Response.Write("<script>window.location='login.aspx';</script>");
            }
            catch (Exception ex)
            {
            }
            finally
            {
                con.Close();
            }
        }
    }
}